# Changelog

All notable changes to `botble-activator` will be documented in this file

## 1.0.0 - 2024-02-29

- First release 🥳
