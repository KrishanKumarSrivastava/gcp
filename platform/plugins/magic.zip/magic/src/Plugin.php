<?php

namespace Shaqi\BotbleActivator;

use Botble\Setting\Facades\Setting;
use Illuminate\Support\Facades\Schema;
use Botble\PluginManagement\Abstracts\PluginOperationAbstract;


class Plugin extends PluginOperationAbstract
{
    public static function activated(): void
    {
 
    }

    public static function remove(): void
    {
      
    }
}
